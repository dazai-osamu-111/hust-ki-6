/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QUANLICUAHANGXEMAYEntity;

/**
 *
 * @author duy
 */
public class Xe {

    private String MaXe;
    private String TenHangXe;
    private String SoLuong;
    private String ThongTinBaoHanh;
    private String TenXe;
    private String NhaSX;
    private String DonGia;
    private String TinhTrang;

    public String getTinhTrang() {
        return TinhTrang;
    }

    public void setTinhTrang(String TinhTrang) {
        this.TinhTrang = TinhTrang;
    }

    public String getMaXe() {
        return MaXe;
    }

    public void setMaXe(String MaXe) {
        this.MaXe = MaXe;
    }

    public String getTenHangXe() {
        return TenHangXe;
    }

    public void setTenHangXe(String TenHangXe) {
        this.TenHangXe = TenHangXe;
    }

    public String getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(String SoLuong) {
        this.SoLuong = SoLuong;
    }

    public String getThongTinBaoHanh() {
        return ThongTinBaoHanh;
    }

    public void setThongTinBaoHanh(String ThongTinBaoHanh) {
        this.ThongTinBaoHanh = ThongTinBaoHanh;
    }

    public String getTenXe() {
        return TenXe;
    }

    public void setTenXe(String TenXe) {
        this.TenXe = TenXe;
    }

    public String getNhaSX() {
        return NhaSX;
    }

    public void setNhaSX(String NhaSX) {
        this.NhaSX = NhaSX;
    }

    public String getDonGia() {
        return DonGia;
    }

    public void setDonGia(String DonGia) {
        this.DonGia = DonGia;
    }
}
