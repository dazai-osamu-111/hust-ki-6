/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QUANLICUAHANGXEMAYEntity;

/**
 *
 * @author duy
 */
public class ChiTietPhieuXuat {

    private String MaPhieuXuat;
    private String MaXe;
    private String SLXuat;
    private String DonGiaXuat;
    private String Thue;

    public String getMaPhieuXuat() {
        return MaPhieuXuat;
    }

    public void setMaPhieuXuat(String MaPhieuXuat) {
        this.MaPhieuXuat = MaPhieuXuat;
    }

    public String getMaXe() {
        return MaXe;
    }

    public void setMaXe(String MaXe) {
        this.MaXe = MaXe;
    }

    public String getSLXuat() {
        return SLXuat;
    }

    public void setSLXuat(String SLXuat) {
        this.SLXuat = SLXuat;
    }

    public String getDonGiaXuat() {
        return DonGiaXuat;
    }

    public void setDonGiaXuat(String DonGiaXuat) {
        this.DonGiaXuat = DonGiaXuat;
    }

    public String getThue() {
        return Thue;
    }

    public void setThue(String Thue) {
        this.Thue = Thue;
    }

    public String getThanhTien() {
        return ThanhTien;
    }

    public void setThanhTien(String ThanhTien) {
        this.ThanhTien = ThanhTien;
    }
    private String ThanhTien;
}
