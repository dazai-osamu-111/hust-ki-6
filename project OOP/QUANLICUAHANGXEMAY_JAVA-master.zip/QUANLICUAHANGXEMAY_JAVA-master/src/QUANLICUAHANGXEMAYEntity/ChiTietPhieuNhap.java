/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QUANLICUAHANGXEMAYEntity;

/**
 *
 * @author duy
 */
public class ChiTietPhieuNhap {

    private String MaPhieuNhap;
    private String MaXe;
    private String SLNhap;
    private String DonGiaNhap;
    private String Thue;
    private String ThanhTien;

    public String getMaPhieuNhap() {
        return MaPhieuNhap;
    }

    public void setMaPhieuNhap(String MaPhieuNhap) {
        this.MaPhieuNhap = MaPhieuNhap;
    }

    public String getMaXe() {
        return MaXe;
    }

    public void setMaXe(String MaXe) {
        this.MaXe = MaXe;
    }

    public String getSLNhap() {
        return SLNhap;
    }

    public void setSLNhap(String SLNhap) {
        this.SLNhap = SLNhap;
    }

    public String getDonGiaNhap() {
        return DonGiaNhap;
    }

    public void setDonGiaNhap(String DonGiaNhap) {
        this.DonGiaNhap = DonGiaNhap;
    }

    public String getThue() {
        return Thue;
    }

    public void setThue(String Thue) {
        this.Thue = Thue;
    }

    public String getThanhTien() {
        return ThanhTien;
    }

    public void setThanhTien(String ThanhTien) {
        this.ThanhTien = ThanhTien;
    }
}
